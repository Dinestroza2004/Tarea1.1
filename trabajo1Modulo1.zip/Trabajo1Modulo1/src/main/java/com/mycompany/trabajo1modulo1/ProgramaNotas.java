/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.trabajo1modulo1;

/**
 *
 * @author Pc
 */
public class ProgramaNotas {
   public static void main(String[] args) {
        String[] nombres = {"Daniel", "Monica"};
        int[] notas = {65, 89};
        
        for (int i = 0; i < nombres.length; i++) {
            System.out.println("Nombre: " + nombres[i]);
            System.out.println("Nota: " + notas[i]);
            if (notas[i] >= 70) {
                System.out.println("Aprobado");
            } else {
                System.out.println("Reprobado");
            }
            System.out.println();
        }
    } 
}

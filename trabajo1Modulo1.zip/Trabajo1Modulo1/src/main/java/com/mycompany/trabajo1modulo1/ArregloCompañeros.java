/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.trabajo1modulo1;

/**
 *
 * @author Pc
 */
public class ArregloCompañeros {
    public static void main(String[] args) {
        String[] nombres = {"GISSELA", "ANDREA", "EROS", "JUAN", "CARLOS", "CINTYA", "DAVID", "DANIA", "EDGAR", "EDUARDO"};
        
        for (String nombre : nombres) {
            System.out.println(nombre);
        }
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.trabajo1modulo1;

/**
 *
 * @author Pc
 */
public class Trabajo1Modulo1 {

     public static void main(String[] args) {
        System.out.println("Hola, soy David Andres Inestroza Gonzales 202320010101");
    }
}

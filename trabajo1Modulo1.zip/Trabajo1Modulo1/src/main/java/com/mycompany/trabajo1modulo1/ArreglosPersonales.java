/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.trabajo1modulo1;

/**
 *
 * @author Pc
 */
public class ArreglosPersonales {
    public static void main(String[] args) {
        String[][] datosCompaneros = {
            {"GISSELA", "MEDINA", "Electronica", "TEST"},
            {"ANDREA", "JIZ", "Computacion", "IMSA"},
            {"EROS", "PEREZ", "Mecatronica", "CEAT"},
            {"JUAN", "GONZALES", "Industrial", "INSA"},
            {"CARLOS", "LOPEZ", "Sistemas", "ABC"}
        };

        for (int i = 0; i < datosCompaneros.length; i++) {
            System.out.println("Nombre: " + datosCompaneros[i][0]);
            System.out.println("Apellido: " + datosCompaneros[i][1]);
            System.out.println("Carrera: " + datosCompaneros[i][2]);
            System.out.println("Lugar de Trabajo: " + datosCompaneros[i][3]);
            System.out.println();
        }
    }
}
